# Türkçeleştirme Notları (AdventureWorks – Power BI Eğitim Seti)

Tüm dosyalar orijinal yapısıyla korundu: aynı dosya adları, aynı tablo/sütun sayısı,
aynı satır sayısı, aynı anahtar değerleri, aynı ayraçlar ve aynı tarih biçimleri.
Yalnızca **sütun adları ve metin içerikleri** Türkçeleştirildi. Kodlama: **UTF-8 (BOM'lu)**
— Power BI ve Excel Türkçe karakterleri sorunsuz okur.

## Doğrulama sonucu

| Kontrol | Sonuç |
|---|---|
| Satır ve sütun sayıları | Tüm dosyalarda birebir aynı |
| Anahtar sütunları (Ürün/Müşteri/Bölge/Kategori) | Değiştirilmedi |
| Tarih, miktar, maliyet, fiyat, gelir alanları | Değiştirilmedi |
| İlişkiler (Satışlar→Ürün/Müşteri/Bölge, İade→Ürün/Bölge, Ürün→Alt Kategori→Kategori) | Eksiksiz |
| Toplam ciro (Miktar × Fiyat) | 24.914.586,82 — orijinaliyle aynı |
| Ürün adı / model / açıklama eşlemesi | 293 / 119 / 115 — bire bir, bilgi kaybı yok |

## Sütun adı karşılıkları

| Orijinal | Türkçe |
|---|---|
| OrderDate / StockDate | Sipariş Tarihi / Stok Tarihi |
| OrderNumber / OrderLineItem / OrderQuantity | Sipariş No / Sipariş Satır No / Sipariş Miktarı |
| ProductKey / CustomerKey / TerritoryKey | Ürün Anahtarı / Müşteri Anahtarı / Bölge Anahtarı |
| ProductSubcategoryKey / ProductCategoryKey | Alt Kategori Anahtarı / Kategori Anahtarı |
| ProductSKU / ProductName / ModelName / ProductDescription | Ürün SKU / Ürün Adı / Model Adı / Ürün Açıklaması |
| ProductColor / ProductSize / ProductStyle | Renk / Beden / Stil |
| ProductCost / ProductPrice | Maliyet / Fiyat |
| CategoryName / SubcategoryName | Kategori Adı / Alt Kategori Adı |
| Region / Country / Continent | Bölge / Ülke / Kıta |
| Prefix / FirstName / LastName / BirthDate | Unvan / Ad / Soyad / Doğum Tarihi |
| MaritalStatus / Gender / EmailAddress | Medeni Hal / Cinsiyet / E-posta |
| AnnualIncome / TotalChildren | Yıllık Gelir / Çocuk Sayısı |
| EducationLevel / Occupation / HomeOwner | Eğitim Düzeyi / Meslek / Ev Sahibi |
| ReturnDate / ReturnQuantity | İade Tarihi / İade Miktarı |
| Date | Tarih |

## Veri karşılıkları

**Kategoriler:** Bikes→Bisikletler, Components→Bileşenler, Clothing→Giyim, Accessories→Aksesuarlar
(37 alt kategori de çevrildi: Mountain Bikes→Dağ Bisikletleri, Tires and Tubes→Lastikler ve İç Lastikler …)

**Ürünler:** Model kodları korundu, açıklayıcı kısımlar çevrildi.
Örnek: `Sport-100 Helmet, Red` → `Sport-100 Kask, Kırmızı`,
`HL Mountain Frame - Silver, 42` → `HL Dağ Kadro - Gümüş, 42`,
`Mountain-500 Black, 40` → `Mountain-500 Siyah, 40`.
SKU kodları (HL-U509-R) ve bedenler (S/M/L/XL, 38–62) aynen kaldı.
115 ürün açıklamasının tamamı Türkçeye çevrildi.

**Bölgeler:** Northwest→Kuzeybatı, Central→Orta, Germany→Almanya, United States→Amerika Birleşik
Devletleri, Europe→Avrupa, Pacific→Pasifik…

**Müşteriler:** 18.148 müşterinin ad ve soyadı, cinsiyetiyle uyumlu Türkçe isimlerle değiştirildi;
e-postalar da bu isimlerden üretildi (`ahmet24@maceradunyasi.com`) ve tekilliği korundu.
Kategorik alanlar: Unvan (BAY / BAYAN / HANIMEFENDİ), Medeni Hal (E/B), Cinsiyet (E/K),
Ev Sahibi (E/H), Eğitim Düzeyi (Lise, Lise Terk, Üniversite Terk, Lisans, Lisansüstü),
Meslek (İşçi, Nitelikli İşçi, Büro Çalışanı, Uzman, Yönetim).
Ürün tablosundaki Stil kodları da E/K/U oldu.

## Eğitimde işinize yarayacak "kirli veri" ayrıntıları (bilerek korundu)

- **Müşteriler.csv** sonunda: 3 adet `30---` anahtarlı boş kayıt (`bay` unvanı küçük harfle),
  1 tamamen boş satır ve 2 dipnot satırı — Türkçeleştirilerek bırakıldı:
  `Dışa aktarma tarihi 20230101 14:59:17`, `Kaynak AW_Cust_Master`. 133 kayıtta Unvan boş.
- **Takvim.csv** içinde geçersiz `2023-02-29` tarihi duruyor (2023 artık yıl değil).
- **İadeler.csv** tarihleri `gg-aa-yy`, **Unpivot** dosyası `a/g/yyyy` biçiminde — Power Query'de
  tarih dönüştürme alıştırması için orijinal biçimler değiştirilmedi.
- **Bölgeler.csv** ayracı noktalı virgül (`;`) olarak korundu.
- **Ürün Kategori Satış Unpivot.csv** üç bölge sütunuyla unpivot alıştırmasına hazır.
